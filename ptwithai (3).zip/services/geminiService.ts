
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, FitnessPlan } from "../types";

export const generateFitnessPlan = async (profile: UserProfile): Promise<FitnessPlan> => {
  const apiKey = process.env.API_KEY;
  
  if (!apiKey || apiKey === "replace_with_your_actual_gemini_api_key") {
    throw new Error("API_KEY_NOT_SET");
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Role: Elite AI Fitness & Nutrition Coach ("Subhchintak") for Indian students.
    Task: Create a high-performance, budget-conscious workout and diet plan.
    
    User Context:
    - Stats: ${profile.age}y, ${profile.gender}, ${profile.height}cm, ${profile.weight}kg
    - Goal: ${profile.fitnessGoal} (Experience: ${profile.experienceLevel})
    - Schedule: ${profile.dailySchedule} per session, ${profile.workoutDays} days/week.
    - Resources: ${profile.workoutResources.join(', ')}
    - Diet: ${profile.dietaryPreference} (${profile.culturalFoodHabit}), Budget: ${profile.monthlyBudget}

    Strict Directives:
    1. EXERCISES: 5-7 moves per session with descriptive YouTube links.
    2. MEALS: Indian-centric, calorie-counted, with "Student-Budget" alternatives.
    3. ADVICE: Mindset and recovery focus.
    
    Output must be valid JSON according to the schema.
  `;

  const mealSchema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING },
      items: { type: Type.ARRAY, items: { type: Type.STRING } },
      portionSizes: { type: Type.STRING },
      approxPrice: { type: Type.STRING },
      calories: { type: Type.STRING },
      cookingInstructions: { type: Type.ARRAY, items: { type: Type.STRING } },
      macros: {
        type: Type.OBJECT,
        properties: {
          protein: { type: Type.STRING },
          carbs: { type: Type.STRING },
          fats: { type: Type.STRING }
        },
        required: ["protein", "carbs", "fats"]
      },
      budgetAlternative: { type: Type.STRING }
    },
    required: ["name", "items", "portionSizes", "approxPrice", "calories", "cookingInstructions", "macros", "budgetAlternative"]
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            userProfileSummary: { type: Type.STRING },
            fitnessGoalAnalysis: { type: Type.STRING },
            weeklyWorkoutPlan: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.STRING },
                  title: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  exercises: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        sets: { type: Type.NUMBER },
                        reps: { type: Type.STRING },
                        rest: { type: Type.STRING },
                        description: { type: Type.STRING },
                        videoUrl: { type: Type.STRING }
                      },
                      required: ["name", "sets", "reps", "rest", "description", "videoUrl"]
                    }
                  }
                },
                required: ["day", "title", "exercises", "duration"]
              }
            },
            dailyDietPlan: {
              type: Type.OBJECT,
              properties: {
                breakfast: mealSchema,
                lunch: mealSchema,
                dinner: mealSchema,
                snacks: { type: Type.ARRAY, items: mealSchema }
              },
              required: ["breakfast", "lunch", "dinner", "snacks"]
            },
            hydrationGuidance: {
              type: Type.OBJECT,
              properties: {
                dailyTarget: { type: Type.STRING },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["dailyTarget", "tips"]
            },
            subhchintakAdvice: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } },
                recoveryAdvice: { type: Type.STRING },
                mindsetQuote: { type: Type.STRING }
              },
              required: ["title", "tips", "recoveryAdvice", "mindsetQuote"]
            },
            budgetOptimizationTips: { type: Type.ARRAY, items: { type: Type.STRING } },
            progressTrackingAdvice: { type: Type.STRING },
            studentMotivationNote: { type: Type.STRING }
          },
          required: [
            "userProfileSummary", "fitnessGoalAnalysis", "weeklyWorkoutPlan", 
            "dailyDietPlan", "hydrationGuidance", "subhchintakAdvice", 
            "budgetOptimizationTips", "progressTrackingAdvice", "studentMotivationNote"
          ]
        }
      }
    });

    if (!response.text) {
      throw new Error("EMPTY_AI_RESPONSE");
    }

    return JSON.parse(response.text);
  } catch (error: any) {
    if (error.message?.includes("API Key must be set") || error.message?.includes("Requested entity was not found")) {
      throw new Error("API_KEY_INVALID");
    }
    throw error;
  }
};
